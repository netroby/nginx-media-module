#ifndef __CAP_FORMAT_H__
#define __CAP_FORMAT_H__

// includes
#include "../media_format.h"

// globals
extern media_format_t cap_format;

#endif //__CAP_FORMAT_H__
