#ifndef _NGX_HTTP_VOD_HLS_H_INCLUDED_
#define _NGX_HTTP_VOD_HLS_H_INCLUDED_

// includes
#include "ngx_http_vod_submodule.h"

// globals
extern const ngx_http_vod_submodule_t hls;

#endif // _NGX_HTTP_VOD_HLS_H_INCLUDED_
